-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2023 at 03:32 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `basketballphoto_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_photos`
--

CREATE TABLE `tbl_photos` (
  `img_id` int(11) NOT NULL,
  `img_name` varchar(255) NOT NULL,
  `img_path` varchar(255) NOT NULL,
  `img_type` varchar(255) NOT NULL,
  `img_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_photos`
--

INSERT INTO `tbl_photos` (`img_id`, `img_name`, `img_path`, `img_type`, `img_title`) VALUES
(29, '800px-Dwyane_Wade.jpg', 'img/800px-Dwyane_Wade.jpg', 'image/jpeg', 'Dwyane Wade'),
(30, '800px-LeBron_James_at_GSW.jpg', 'img/800px-LeBron_James_at_GSW.jpg', 'image/jpeg', 'Lebron James'),
(31, '1991-06-12-Gm-5-v-LAL-1991-NBA-Finals-Michael-Jordan-dunk-NBAE-Andrew-Bernstein.jpg', 'img/1991-06-12-Gm-5-v-LAL-1991-NBA-Finals-Michael-Jordan-dunk-NBAE-Andrew-Bernstein.jpg', 'image/jpeg', 'Michael Jordan'),
(32, 'James_Yap_vs_ROS.jpg', 'img/James_Yap_vs_ROS.jpg', 'image/jpeg', 'James Yap'),
(33, 'Converse Wade 3 Right Way Red and Black.jpg', 'img/Converse Wade 3 Right Way Red and Black.jpg', 'image/jpeg', 'Converse Wade 3'),
(34, 'Nike Lebron X Black and Red.JPG', 'img/Nike Lebron X Black and Red.JPG', 'image/jpeg', 'Nike Lebron 10'),
(35, 'Air Jordan 12 Red.jpg', 'img/Air Jordan 12 Red.jpg', 'image/jpeg', 'Air Jordan 12 '),
(36, 'Nike Kobe 9 Black Mamba.png', 'img/Nike Kobe 9 Black Mamba.png', 'image/png', 'Nike Kobe IX Black Mamba'),
(37, 'Adidas Logo Red Headband.png', 'img/Adidas Logo Red Headband.png', 'image/png', 'Adidas Logo Red Headband'),
(38, 'Nba Logo Black Headband.jpg', 'img/Nba Logo Black Headband.jpg', 'image/jpeg', 'NBA Logo Black Headband'),
(39, 'Air Jordan Logo Red and Black Headband.png', 'img/Air Jordan Logo Red and Black Headband.png', 'image/png', 'Air Jordan Logo Red Headband'),
(40, 'Nike Logo Black Headband.jpg', 'img/Nike Logo Black Headband.jpg', 'image/jpeg', 'Nike Logo Black Headband'),
(41, 'Converse Logo Black Wristband.png', 'img/Converse Logo Black Wristband.png', 'image/png', 'Converse Logo Black Wristband'),
(42, 'Nba Logo Black Wristband.png', 'img/Nba Logo Black Wristband.png', 'image/png', 'NBA Logo Black Wristband'),
(43, 'Air Jordan Red Wristband.jpg', 'img/Air Jordan Red Wristband.jpg', 'image/jpeg', 'Air Jordan Red Wristband'),
(44, 'Nike Logo Black Wristband.jpg', 'img/Nike Logo Black Wristband.jpg', 'image/jpeg', 'Nike Logo Black Wristband'),
(45, 'Nba Logo Black Arm Sleeve.jpg', 'img/Nba Logo Black Arm Sleeve.jpg', 'image/jpeg', 'NBA Logo Black Arm Sleeve'),
(46, 'Adidas Tech Fit Red Arm Sleeve.jpg', 'img/Adidas Tech Fit Red Arm Sleeve.jpg', 'image/jpeg', 'Adidas Tech Fit Red Arm Sleeve'),
(47, 'Air Jordan Black Arm Sleeve.jpg', 'img/Air Jordan Black Arm Sleeve.jpg', 'image/jpeg', 'Air Jordan Black Arm Sleeve'),
(48, 'McDavid Logo Red Hex Pad Arm Sleeve.png', 'img/McDavid Logo Red Hex Pad Arm Sleeve.png', 'image/png', 'McDavid Logo Red Hex Pad Arm Sleeve');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_photos`
--
ALTER TABLE `tbl_photos`
  ADD PRIMARY KEY (`img_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_photos`
--
ALTER TABLE `tbl_photos`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
